﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace WindowsFormsApp1
{
    public partial class Дсотрудники : Form
    {
        public Дсотрудники()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            OleDbConnection con = new OleDbConnection(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=Автошкола (2).accdb;");
            con.Open();

            string query = $"INSERT INTO [Сотрудники] ([ФИО], [Роль], [Автомобиль], [Номер], [Категория вождения]) VALUES ('{tbFio.Text}', '{tbRol.Text}', '{tbAvto.Text}', '{tbNum.Text}', '{tbKat.Text}')";

            OleDbCommand cmd = new OleDbCommand(query, con);
            cmd.ExecuteNonQuery();

            con.Close();
            MessageBox.Show("Добавлено");
            Close();
        }
    }
}
