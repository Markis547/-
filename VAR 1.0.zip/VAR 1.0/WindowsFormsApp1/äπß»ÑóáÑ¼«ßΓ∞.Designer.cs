﻿namespace WindowsFormsApp1
{
    partial class Дуспеваемость
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.tbIDkurs = new System.Windows.Forms.TextBox();
            this.tbOcen = new System.Windows.Forms.TextBox();
            this.tbIDzan = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(32, 44);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(52, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "ID_kurs";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(32, 91);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(56, 16);
            this.label2.TabIndex = 1;
            this.label2.Text = "Оценка";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(36, 139);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(48, 16);
            this.label3.TabIndex = 2;
            this.label3.Text = "ID_zan";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(98, 217);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(92, 23);
            this.button1.TabIndex = 6;
            this.button1.Text = "Сохранить";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // tbIDkurs
            // 
            this.tbIDkurs.Location = new System.Drawing.Point(131, 41);
            this.tbIDkurs.Name = "tbIDkurs";
            this.tbIDkurs.Size = new System.Drawing.Size(100, 22);
            this.tbIDkurs.TabIndex = 7;
            // 
            // tbOcen
            // 
            this.tbOcen.Location = new System.Drawing.Point(131, 88);
            this.tbOcen.Name = "tbOcen";
            this.tbOcen.Size = new System.Drawing.Size(100, 22);
            this.tbOcen.TabIndex = 8;
            // 
            // tbIDzan
            // 
            this.tbIDzan.Location = new System.Drawing.Point(131, 136);
            this.tbIDzan.Name = "tbIDzan";
            this.tbIDzan.Size = new System.Drawing.Size(100, 22);
            this.tbIDzan.TabIndex = 9;
            // 
            // Дуспеваемость
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(304, 271);
            this.Controls.Add(this.tbIDzan);
            this.Controls.Add(this.tbOcen);
            this.Controls.Add(this.tbIDkurs);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Дуспеваемость";
            this.Text = "Успеваемость";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox tbIDkurs;
        private System.Windows.Forms.TextBox tbOcen;
        private System.Windows.Forms.TextBox tbIDzan;
    }
}