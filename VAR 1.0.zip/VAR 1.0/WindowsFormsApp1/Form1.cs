﻿
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        private string connString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=Автошкола (2).accdb;";
        private string currentTable = "Группы";

        public Form1()
        {
            InitializeComponent();
        }

        private void LoadData(string tableName)
        {
            currentTable = tableName;
            try
            {
                using (OleDbConnection conn = new OleDbConnection(connString))
                {
                    OleDbDataAdapter da = new OleDbDataAdapter($"SELECT * FROM [{tableName}]", conn);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    dataGridView1.Columns.Clear();
                    dataGridView1.DataSource = dt;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dataGridView1.MultiSelect = false;
            LoadData("Группы");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            LoadData("Группы");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            LoadData("Занятия");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            LoadData("Курсанты");
        }

        private void button4_Click(object sender, EventArgs e)
        {
            LoadData("Успеваемость");
        }

        private void button5_Click(object sender, EventArgs e)
        {
            LoadData("Сотрудники");
        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (currentTable == "Группы")
            {
                Дгруппы f = new Дгруппы();
                f.ShowDialog();
            }
            else if (currentTable == "Занятия")
            {
                Дзанятия f = new Дзанятия();
                f.ShowDialog();
            }
            else if (currentTable == "Курсанты")
            {
                Дкурсанты f = new Дкурсанты();
                f.ShowDialog();
            }
            else if (currentTable == "Успеваемость")
            {
                Дуспеваемость f = new Дуспеваемость();
                f.ShowDialog();
            }
            else if (currentTable == "Сотрудники")
            {
                Дсотрудники f = new Дсотрудники();
                f.ShowDialog();
            }

            LoadData(currentTable);
        }

        private void button7_Click(object sender, EventArgs e)
        {
            if (dataGridView1.CurrentRow == null)
            {
                MessageBox.Show("Выделите строку");
                return;
            }

            DialogResult dr = MessageBox.Show("Удалить выбранную запись?", "Удаление", MessageBoxButtons.YesNo);
            if (dr == DialogResult.Yes)
            {
                try
                {
                    string idColumnName = ((DataTable)dataGridView1.DataSource).Columns[0].ColumnName;
                    object idValue = dataGridView1.CurrentRow.Cells[idColumnName].Value;

                    using (OleDbConnection conn = new OleDbConnection(connString))
                    {
                        conn.Open();
                        string query = $"DELETE FROM [{currentTable}] WHERE [{idColumnName}] = ?";
                        using (OleDbCommand cmd = new OleDbCommand(query, conn))
                        {
                            cmd.Parameters.AddWithValue("?", idValue);
                            cmd.ExecuteNonQuery();
                        }
                    }

                    LoadData(currentTable);
                    MessageBox.Show("Запись удалена");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }
    }
}