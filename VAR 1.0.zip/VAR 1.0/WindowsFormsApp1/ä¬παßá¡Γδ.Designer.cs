﻿namespace WindowsFormsApp1
{
    partial class Дкурсанты
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.tbFioCurs = new System.Windows.Forms.TextBox();
            this.tbHap = new System.Windows.Forms.TextBox();
            this.tbNumCurs = new System.Windows.Forms.TextBox();
            this.tbOpl = new System.Windows.Forms.TextBox();
            this.tbIDprep = new System.Windows.Forms.TextBox();
            this.tbGrupp = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(64, 67);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(38, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "ФИО";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(64, 110);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(104, 16);
            this.label2.TabIndex = 1;
            this.label2.Text = "ДатаРождения";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(64, 164);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(67, 16);
            this.label3.TabIndex = 2;
            this.label3.Text = "Телефон";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(64, 212);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(103, 16);
            this.label4.TabIndex = 3;
            this.label4.Text = "СтатусОплаты";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(64, 261);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(71, 16);
            this.label5.TabIndex = 4;
            this.label5.Text = "ID_prepod";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(64, 312);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(54, 16);
            this.label6.TabIndex = 5;
            this.label6.Text = "Группа";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(168, 380);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(96, 23);
            this.button1.TabIndex = 12;
            this.button1.Text = "Сохранить";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // tbFioCurs
            // 
            this.tbFioCurs.Location = new System.Drawing.Point(206, 64);
            this.tbFioCurs.Name = "tbFioCurs";
            this.tbFioCurs.Size = new System.Drawing.Size(180, 22);
            this.tbFioCurs.TabIndex = 13;
            // 
            // tbHap
            // 
            this.tbHap.Location = new System.Drawing.Point(206, 107);
            this.tbHap.Name = "tbHap";
            this.tbHap.Size = new System.Drawing.Size(180, 22);
            this.tbHap.TabIndex = 14;
            // 
            // tbNumCurs
            // 
            this.tbNumCurs.Location = new System.Drawing.Point(206, 161);
            this.tbNumCurs.Name = "tbNumCurs";
            this.tbNumCurs.Size = new System.Drawing.Size(180, 22);
            this.tbNumCurs.TabIndex = 15;
            // 
            // tbOpl
            // 
            this.tbOpl.Location = new System.Drawing.Point(206, 209);
            this.tbOpl.Name = "tbOpl";
            this.tbOpl.Size = new System.Drawing.Size(180, 22);
            this.tbOpl.TabIndex = 16;
            // 
            // tbIDprep
            // 
            this.tbIDprep.Location = new System.Drawing.Point(206, 258);
            this.tbIDprep.Name = "tbIDprep";
            this.tbIDprep.Size = new System.Drawing.Size(180, 22);
            this.tbIDprep.TabIndex = 17;
            // 
            // tbGrupp
            // 
            this.tbGrupp.Location = new System.Drawing.Point(206, 309);
            this.tbGrupp.Name = "tbGrupp";
            this.tbGrupp.Size = new System.Drawing.Size(180, 22);
            this.tbGrupp.TabIndex = 18;
            // 
            // Дкурсанты
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(464, 426);
            this.Controls.Add(this.tbGrupp);
            this.Controls.Add(this.tbIDprep);
            this.Controls.Add(this.tbOpl);
            this.Controls.Add(this.tbNumCurs);
            this.Controls.Add(this.tbHap);
            this.Controls.Add(this.tbFioCurs);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Дкурсанты";
            this.Text = "Курсанты";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox tbFioCurs;
        private System.Windows.Forms.TextBox tbHap;
        private System.Windows.Forms.TextBox tbNumCurs;
        private System.Windows.Forms.TextBox tbOpl;
        private System.Windows.Forms.TextBox tbIDprep;
        private System.Windows.Forms.TextBox tbGrupp;
    }
}