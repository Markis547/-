﻿namespace WindowsFormsApp1
{
    partial class Дгруппы
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.tbIDprepGR = new System.Windows.Forms.TextBox();
            this.tbCatVoz = new System.Windows.Forms.TextBox();
            this.tbDvoz = new System.Windows.Forms.TextBox();
            this.tbDakz = new System.Windows.Forms.TextBox();
            this.tbMax = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(43, 51);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(71, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "ID_prepod";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(43, 103);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(75, 16);
            this.label2.TabIndex = 1;
            this.label2.Text = "Категория";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(43, 155);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(89, 16);
            this.label3.TabIndex = 2;
            this.label3.Text = "ДатаНачала";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(43, 203);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(105, 16);
            this.label4.TabIndex = 3;
            this.label4.Text = "ДатаЭкзамена";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(43, 251);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(154, 16);
            this.label5.TabIndex = 4;
            this.label5.Text = "МаксКол-воКурсантов";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(194, 342);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(87, 28);
            this.button1.TabIndex = 10;
            this.button1.Text = "Сохранить";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // tbIDprepGR
            // 
            this.tbIDprepGR.Location = new System.Drawing.Point(220, 48);
            this.tbIDprepGR.Name = "tbIDprepGR";
            this.tbIDprepGR.Size = new System.Drawing.Size(211, 22);
            this.tbIDprepGR.TabIndex = 11;
            // 
            // tbCatVoz
            // 
            this.tbCatVoz.Location = new System.Drawing.Point(220, 100);
            this.tbCatVoz.Name = "tbCatVoz";
            this.tbCatVoz.Size = new System.Drawing.Size(211, 22);
            this.tbCatVoz.TabIndex = 12;
            // 
            // tbDvoz
            // 
            this.tbDvoz.Location = new System.Drawing.Point(220, 152);
            this.tbDvoz.Name = "tbDvoz";
            this.tbDvoz.Size = new System.Drawing.Size(211, 22);
            this.tbDvoz.TabIndex = 13;
            // 
            // tbDakz
            // 
            this.tbDakz.Location = new System.Drawing.Point(220, 200);
            this.tbDakz.Name = "tbDakz";
            this.tbDakz.Size = new System.Drawing.Size(211, 22);
            this.tbDakz.TabIndex = 14;
            // 
            // tbMax
            // 
            this.tbMax.Location = new System.Drawing.Point(220, 248);
            this.tbMax.Name = "tbMax";
            this.tbMax.Size = new System.Drawing.Size(211, 22);
            this.tbMax.TabIndex = 15;
            // 
            // Дгруппы
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(492, 408);
            this.Controls.Add(this.tbMax);
            this.Controls.Add(this.tbDakz);
            this.Controls.Add(this.tbDvoz);
            this.Controls.Add(this.tbCatVoz);
            this.Controls.Add(this.tbIDprepGR);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Дгруппы";
            this.Text = "Группы";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox tbIDprepGR;
        private System.Windows.Forms.TextBox tbCatVoz;
        private System.Windows.Forms.TextBox tbDvoz;
        private System.Windows.Forms.TextBox tbDakz;
        private System.Windows.Forms.TextBox tbMax;
    }
}