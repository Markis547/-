﻿namespace WindowsFormsApp1
{
    partial class Дсотрудники
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.tbFio = new System.Windows.Forms.TextBox();
            this.tbRol = new System.Windows.Forms.TextBox();
            this.tbAvto = new System.Windows.Forms.TextBox();
            this.tbNum = new System.Windows.Forms.TextBox();
            this.tbKat = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(37, 43);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(38, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "ФИО";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(37, 91);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(39, 16);
            this.label2.TabIndex = 1;
            this.label2.Text = "Роль";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(37, 132);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(87, 16);
            this.label3.TabIndex = 2;
            this.label3.Text = "Автомобиль";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(37, 174);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(50, 16);
            this.label4.TabIndex = 3;
            this.label4.Text = "Номер";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(37, 212);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(142, 16);
            this.label5.TabIndex = 4;
            this.label5.Text = "Категория вождения";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(177, 270);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(103, 23);
            this.button1.TabIndex = 10;
            this.button1.Text = "Сохранить";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // tbFio
            // 
            this.tbFio.Location = new System.Drawing.Point(197, 40);
            this.tbFio.Name = "tbFio";
            this.tbFio.Size = new System.Drawing.Size(195, 22);
            this.tbFio.TabIndex = 11;
            // 
            // tbRol
            // 
            this.tbRol.Location = new System.Drawing.Point(197, 88);
            this.tbRol.Name = "tbRol";
            this.tbRol.Size = new System.Drawing.Size(195, 22);
            this.tbRol.TabIndex = 12;
            // 
            // tbAvto
            // 
            this.tbAvto.Location = new System.Drawing.Point(197, 129);
            this.tbAvto.Name = "tbAvto";
            this.tbAvto.Size = new System.Drawing.Size(195, 22);
            this.tbAvto.TabIndex = 13;
            // 
            // tbNum
            // 
            this.tbNum.Location = new System.Drawing.Point(197, 171);
            this.tbNum.Name = "tbNum";
            this.tbNum.Size = new System.Drawing.Size(195, 22);
            this.tbNum.TabIndex = 14;
            // 
            // tbKat
            // 
            this.tbKat.Location = new System.Drawing.Point(197, 209);
            this.tbKat.Name = "tbKat";
            this.tbKat.Size = new System.Drawing.Size(195, 22);
            this.tbKat.TabIndex = 15;
            // 
            // Дсотрудники
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(495, 319);
            this.Controls.Add(this.tbKat);
            this.Controls.Add(this.tbNum);
            this.Controls.Add(this.tbAvto);
            this.Controls.Add(this.tbRol);
            this.Controls.Add(this.tbFio);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Дсотрудники";
            this.Text = "Сотрудники";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox tbFio;
        private System.Windows.Forms.TextBox tbRol;
        private System.Windows.Forms.TextBox tbAvto;
        private System.Windows.Forms.TextBox tbNum;
        private System.Windows.Forms.TextBox tbKat;
    }
}