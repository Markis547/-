﻿using System;
using System.Data.OleDb;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace WindowsFormsApp1
{
    public partial class Дгруппы : Form
    {
        public Дгруппы()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            OleDbConnection con = new OleDbConnection(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=Автошкола (2).accdb;");
            con.Open();

            string query = $"INSERT INTO [Группы] ([ID_prepod], [Категория], [ДатаНачала], [ДатаЭкзамена], [МаксКол-воКурсантов]) VALUES ({tbIDprepGR.Text}, '{tbCatVoz.Text}', '{tbDvoz.Text}', '{tbDakz.Text}', {tbMax.Text})";

            OleDbCommand cmd = new OleDbCommand(query, con);
            cmd.ExecuteNonQuery();

            con.Close();
            MessageBox.Show("Добавлено");
            Close();
        }
    }
}