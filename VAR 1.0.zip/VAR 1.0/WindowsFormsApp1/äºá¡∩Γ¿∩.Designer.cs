﻿namespace WindowsFormsApp1
{
    partial class Дзанятия
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.tbDatZan = new System.Windows.Forms.TextBox();
            this.tbTipZan = new System.Windows.Forms.TextBox();
            this.tbDop = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(54, 71);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(93, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "ДатаЗанятия";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(54, 126);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(86, 16);
            this.label2.TabIndex = 1;
            this.label2.Text = "ТипЗанятия";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(54, 179);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(87, 16);
            this.label3.TabIndex = 2;
            this.label3.Text = "ДопусккГАИ";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(146, 256);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(95, 30);
            this.button1.TabIndex = 6;
            this.button1.Text = "Сохранить";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // tbDatZan
            // 
            this.tbDatZan.Location = new System.Drawing.Point(185, 68);
            this.tbDatZan.Name = "tbDatZan";
            this.tbDatZan.Size = new System.Drawing.Size(163, 22);
            this.tbDatZan.TabIndex = 7;
            // 
            // tbTipZan
            // 
            this.tbTipZan.Location = new System.Drawing.Point(185, 123);
            this.tbTipZan.Name = "tbTipZan";
            this.tbTipZan.Size = new System.Drawing.Size(163, 22);
            this.tbTipZan.TabIndex = 8;
            // 
            // tbDop
            // 
            this.tbDop.Location = new System.Drawing.Point(185, 176);
            this.tbDop.Name = "tbDop";
            this.tbDop.Size = new System.Drawing.Size(163, 22);
            this.tbDop.TabIndex = 9;
            // 
            // Дзанятия
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(413, 313);
            this.Controls.Add(this.tbDop);
            this.Controls.Add(this.tbTipZan);
            this.Controls.Add(this.tbDatZan);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Дзанятия";
            this.Text = "Занятия";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox tbDatZan;
        private System.Windows.Forms.TextBox tbTipZan;
        private System.Windows.Forms.TextBox tbDop;
    }
}